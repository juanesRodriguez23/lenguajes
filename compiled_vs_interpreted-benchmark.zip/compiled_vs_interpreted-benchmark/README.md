# Compilado vs Interpretado — Benchmark con Algoritmo Iterativo vs Recursivo

> **Objetivo:** Comparar el desempeño entre un lenguaje **compilado (C++)** y un lenguaje **interpretado (Python)**
> usando el mismo algoritmo (Fibonacci) en dos variantes: **iterativa** y **recursiva**, en la **misma arquitectura**.
> Se generan **gráficas** y un **análisis** reproducible.

---

## 📦 Estructura del repositorio

```
compiled_vs_interpreted-benchmark/
├─ README.md
├─ LICENSE
├─ .gitignore
├─ cpp/
│  ├─ Makefile
│  └─ fib.cpp
├─ python/
│  └─ fib.py
├─ scripts/
│  └─ run_benchmarks.sh
├─ analysis/
│  └─ plot_results.py
└─ results/
   └─ (CSV y PNG generados)
```

---

## 🔧 Requisitos

- **Misma arquitectura** para todas las pruebas (corra todo en la misma máquina):
  - Compilador C++ (por ejemplo `g++ ≥ 9`) 
  - Python 3.8+ con `matplotlib` y `pandas`
  - Bash (para ejecutar el script `run_benchmarks.sh` en Linux/Mac/WSL). En Windows puro, use Git Bash o ejecute los comandos manualmente.

Instale dependencias de Python:
```bash
python -m pip install -r <(echo "pandas
matplotlib")
```
O manualmente:
```bash
python -m pip install pandas matplotlib
```

---

## 🚀 Cómo ejecutar los benchmarks

1) **Compilar C++**
```bash
cd cpp
make clean && make
cd ..
```

2) **Correr todo el benchmark y generar CSVs**
```bash
bash scripts/run_benchmarks.sh
```

- Esto produce `results/bench_results.csv` con columnas:
  - `lang` (`compiled_cpp` | `interpreted_python`)
  - `algorithm` (`iterative` | `recursive`)
  - `n` (tamaño de entrada)
  - `repeats` (número de repeticiones)
  - `avg_ms` (tiempo promedio en milisegundos)

3) **Graficar resultados**
```bash
python analysis/plot_results.py
```
- Salidas:
  - `results/runtime_by_lang_algo.png`
  - `results/runtime_logscale.png`

---

## 📊 Algoritmo

Se usa **Fibonacci** por ser clásico y permitir contrastar fuertemente:
- **Recursivo (sin memoización):** complejidad exponencial O(φⁿ). Muestra muy bien penalizaciones de interpretación y overhead de llamadas.
- **Iterativo:** complejidad O(n), mínima sobrecarga, permite observar diferencias más “puras” de ejecución.

> Nota: usamos exactamente la *misma definición funcional* en ambos lenguajes y evitamos optimizaciones no comparables (sin memoización ni trucos).

---

## ⚖️ Parámetros del experimento

- Valores de `n` por defecto (puede ajustarlos en `scripts/run_benchmarks.sh`):
  - Recursivo: `n ∈ {10, 20, 25, 30, 35}` (suba/baje con cautela)
  - Iterativo:  `n ∈ {1e5, 2e5, 5e5, 1e6}`
- `repeats=5` por punto para estabilidad.
- Compilación C++ con `-O2` para representar un flujo común de optimización.

---

## 🧪 Validez experimental

- **Misma arquitectura y máquina.** No mezclar resultados de equipos distintos.
- Cerrar aplicaciones pesadas y ejecutar en condiciones lo más estables posible.
- Mantener el plan de energía en “alto desempeño” si aplica.

---

## 🧠 Análisis esperado (guía)**

1. **Recursivo:** 
   - El crecimiento del tiempo debe ser **exponencial** en ambos lenguajes.
   - C++ (compilado) tiende a ser significativamente más rápido por:
     - Resolución de llamadas en tiempo de compilación (mejor inlining posible, aunque aquí no aplica por recursión no terminal).
     - Menor overhead de *stack frames* y llamadas.
     - Código máquina optimizado.

2. **Iterativo:**
   - Comportamiento **lineal** con la entrada.
   - La diferencia entre C++ y Python sigue siendo notoria, pero menor en orden de magnitud que en recursivo para `n` moderados.

3. **Interpretado vs Compilado:**
   - Python acarrea overhead del *intérprete* y *tipos dinámicos*.
   - C++ compila a código nativo con tipos estáticos y optimizaciones a nivel de CPU.

4. **Conclusión:** 
   - Para cargas computacionales intensas y críticas en tiempo, el compilado **suele** ganar.
   - Python brilla en **productividad**, bibliotecas y *glue code*. Vía *bindings* (NumPy, Cython, etc.) se puede combinar lo mejor de ambos mundos.

Incluya en su *entrega* capturas/PNG generados y un párrafo final con sus observaciones concretas basadas en sus números.

---

## 📁 Cómo publicar en GitHub (pasos rápidos)

```bash
# 1) Dentro de la carpeta del proyecto
git init
git add .
git commit -m "Benchmark: compilado (C++) vs interpretado (Python) con iterativo y recursivo"

# 2) Cree un repo vacío en GitHub (GUI). Luego:
git branch -M main
git remote add origin https://github.com/<su-usuario>/compiled_vs_interpreted-benchmark.git
git push -u origin main
```

> **Entrega:** comparta el **enlace** a su repositorio público (incluya gráficas y su análisis en el README).

---

## 📜 Licencia

Este proyecto se publica bajo licencia **MIT** (ver `LICENSE`).

